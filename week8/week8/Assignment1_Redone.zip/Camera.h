#pragma once
#include "W_MaterialManager.h"

enum CameraMode { FirstPerson, Static };

class Camera
{
public:
	
	Camera(const glm::vec3& position,const glm::vec3& direction);
	void setStaticCamera(const glm::vec3& position, const glm::vec3& direction);
	void setMode(int mode);
	void update(float deltaf);
	void setNear(float near);
	void setFar(float far);
	const glm::mat4& getViewMatrix();
	const glm::mat4& getProjectionMatrix();

	


private:
	void firstPerson();
	void staticCam();


	float mNear = 0.1f;
	float mFar = 100.0f;

	glm::mat4 mView = glm::lookAt(glm::vec3(0.0f, 20.0f, 60.0f), glm::vec3(20.0f, 0.0f, 0.0f), glm::vec3(0.0f, 1.0f, 0.0f));
	glm::mat4 mProj = glm::perspective(45.0f, 1280.0f / 720.0f, mNear, mFar);

	glm::vec3 mPosition = glm::vec3(0.0f, 0.0f, 5.0f);
	glm::vec3 mDirection = glm::vec3(0.0f,0.0f,0.0f);
	float mHorizontalAngle = 3.14f;
    float mVerticalAngle = 0.0f;


	float mSpeed = 0.5f;
	float mMouseSpeed = 0.0005f;

	int mCameraMode = Static;
	
	
};
