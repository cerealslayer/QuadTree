#define GLFW_INCLUDE_GL3
#define GLFW_NO_GLU
#include <stdio.h>
#include <stdlib.h>
#ifndef __APPLE__
#include <GL/glew.h>
#endif
#include <GL/glfw.h>
#include "W_Common.h"
#include "W_BufferManager.h"
#include "W_VertexDeclaration.h"
#include "W_TextureManager.h"
#include "W_MaterialManager.h"
#include "Camera.h"
#include <iostream>

using namespace std;

Camera::Camera(const glm::vec3& position,const glm::vec3& direction)
{
	this->mPosition = position;
	this->mDirection = direction;
}
void Camera::setStaticCamera(const glm::vec3& position, const glm::vec3& direction)
{
	this->mPosition = position;
	this->mDirection = direction;
	this->mCameraMode = Static;
}

void Camera::setMode(int mode)
{
	if (mode == CameraMode::FirstPerson)
	{
		this->mCameraMode = CameraMode::FirstPerson;
	}
	else
	{
		this->mCameraMode = CameraMode::Static;
	}
}

const glm::mat4& Camera::getViewMatrix()
{
	return this->mView;
}
const glm::mat4& Camera::getProjectionMatrix()
{
	return this->mProj;
}

void Camera::setNear(float near)
{
	this->mNear = near;
	this->mProj = glm::perspective(45.0f, 1280.0f / 720.0f, this->mNear, this->mFar);
}

void Camera::setFar(float far)
{
	this->mFar = far;
	this->mProj = glm::perspective(45.0f, 1280.0f / 720.0f, this->mNear, this->mFar);
}

void Camera::update(float deltaf)
{
	
	if (this->mCameraMode == CameraMode::Static)
	{
		staticCam();
	}
	else
	{
		firstPerson();
	}
	

}
void Camera::staticCam()
{
	
	this->mView = glm::lookAt(mPosition,mDirection, glm::vec3(0.0f, 1.0f, 0.0f));
	
}
void Camera::firstPerson()
{
	int xpos, ypos;
	glfwGetMousePos(&xpos, &ypos);
	glfwSetMousePos(1024 / 2, 768 / 2);

	this->mHorizontalAngle += this->mMouseSpeed * float(1024 / 2 - xpos);
	this->mVerticalAngle += this->mMouseSpeed * float(768 / 2 - ypos);

	this->mDirection = glm::vec3(
		cos(this->mVerticalAngle) * sin(this->mHorizontalAngle),
		sin(this->mVerticalAngle),
		cos(this->mVerticalAngle) * cos(this->mHorizontalAngle)
	);

	glm::vec3 right = glm::vec3(
		sin(this->mHorizontalAngle - 3.14f / 2.0f),
		0,
		cos(this->mHorizontalAngle - 3.14f / 2.0f)
	);

	// Move forward
	if (glfwGetKey(GLFW_KEY_UP) == GLFW_PRESS) {
		mPosition += mDirection * mSpeed;
	}
	// Move backward
	if (glfwGetKey(GLFW_KEY_DOWN) == GLFW_PRESS) {
		mPosition -= mDirection * mSpeed;
	}
	// Strafe right
	if (glfwGetKey(GLFW_KEY_RIGHT) == GLFW_PRESS) {
		mPosition += right * mSpeed;
	}
	// Strafe left
	if (glfwGetKey(GLFW_KEY_LEFT) == GLFW_PRESS) {
		mPosition -= right * mSpeed;
	}

	this->mView = glm::lookAt(mPosition, mPosition + mDirection, glm::vec3(0.0f, 1.0f, 0.0f));

}
